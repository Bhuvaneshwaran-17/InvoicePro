from InventoryManager import InventoryManager
from Invoice import Invoice

def process(x, inv):
    match x.upper():
        case "A":
            name = input("📦 Product name: ")
            price = int(input("💰 Price (per stock): "))
            stock = int(input("📦 Number of stocks: "))
            inv.add_product(name, price, stock)

        case "B":
            pid = input("🔁 Enter Product ID to update: ")
            price = int(input("💰 New price: "))
            stock = int(input("📦 New stock: "))
            inv.update_product(pid, price, stock)

        case "C":
            customer = input(" Enter customer name: ")
            invoice = Invoice(customer)

            while True:
                product = input("🛒 Product id (or 'done' to finish): ")
                if product.lower() == "done":
                    break
                quantity = int(input(" Quantity: "))
                invoice.add_item(product, quantity)

            invoice.calculate_total()
            invoice.print_invoice()

        case "D":
            print("Listing current stock:")
            inv.load_stock()

        case "E":
            print("Exiting the program.")
            return False

        case _:
            print("Invalid option. Please try again.")

    return True


def main():
    inv = InventoryManager()

    while True:
        print("\n Welcome to Inventory Management")
        print("A - Add product to inventory")
        print("B - Update product in inventory")
        print("C - Generate invoice for a customer")
        print("D - List all product stock")
        print("E - Exit")
        x = input("Select an option: ")

        if not process(x, inv):
            break

if __name__ == "__main__":
    main()
