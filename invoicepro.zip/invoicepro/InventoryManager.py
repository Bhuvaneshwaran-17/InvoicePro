from Product import Product
import json
class InventoryManager:
  def add_product(self,name,price,stock):
    product = Product(name,price,stock)
    try:
      with open("stock.json","r") as fe:
        data = json.load(fe)
    except:
      print(f"file not found, creating a new one")
      data = {}
    data[str(product.id)] = product.to_dict()
    with open("stock.json","w") as f:
      json.dump(data,f, indent = 4)
    print(f"product {name} is added with the stock of {stock} at a price of {price}. ")


  def update_product(self,id,price,stock):
    with open("stock.json","r") as update_file:
      data = json.load(update_file)
    pro = Product.from_dict(data[id])
    pro.update_stock(price,stock)


  def load_stock(self):
    try:
      with open("stock.json","r") as load_file:
        data = json.load(load_file)
    except:
      print("file not found")
      return
    for i,j in data.items():
      print(f"Id = {i} : items = {j['name'], j['price'], j['stock']}")

