from InvoiceItem import InvoiceItem
import json
class Invoice:
  def __init__(self,customer_name):
    self.customer_name = customer_name
    self.items = []
    self.tax = 0
    self.total = 0
    self.sub_total = 0



  def add_item(self, product_id, quantity):
      try:
          with open("stock.json", "r") as f:
              data = json.load(f)
      except FileNotFoundError:
          print("Stock file not found.")
          return

      if product_id not in data:
          print(f"Product with ID {product_id} not found.")
          return

      product_info = data[product_id]
      price = product_info["price"]
      available_stock = product_info["stock"]

      if quantity > available_stock:
          print(f"Not enough stock. Available: {available_stock}")
          return

      total_price = price * quantity
      product_name = product_info["name"]

      item = InvoiceItem(product_name, quantity, total_price)
      self.items.append(item)
      print(f"Added: {product_name} x {quantity} = ₹{total_price}")


      data[product_id]["stock"] -= quantity
      with open("stock.json", "w") as f:
          json.dump(data, f, indent=4)


  def calculate_total(self):
    self.sub_total = 0
    for i in self.items:
      self.sub_total+=i.total_price
    self.tax = self.sub_total * 0.05
    self.total = self.sub_total + self.tax
    return self.total

  def print_invoice(self, filename="invoice.txt"):
    self.calculate_total()

    with open(filename, "w") as f:
        f.write(f"Invoice for: {self.customer_name}\n")
        f.write("=" * 40 + "\n")
        for item in self.items:
            f.write(f"{item.product:<20} x {item.quantity:<3} = ₹{item.total_price}\n")
        f.write("-" * 40 + "\n")
        f.write(f"Subtotal: ₹{self.sub_total}\n")
        f.write(f"Tax (5%): ₹{self.tax}\n")
        f.write(f"Total: ₹{self.total}\n")

    print(f"Invoice saved to '{filename}'")



