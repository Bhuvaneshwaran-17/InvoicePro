import json
import uuid
class Product:
  def __init__(self,name,price,stock,id=None):
    self.id = id if id else str(uuid.uuid4())
    self.name = name
    self.price = price
    self.stock = stock

  def update_stock(self,price,stock):
    with open("stock.json","r") as f:
      data = json.load(f)
    if self.id not in data:
      print(f"product with id{id} not found")
      return
    data[self.id]["price"] = price
    data[self.id]["stock"] = stock
    name = data[self.id]["name"]
    with open("stock.json","w") as fi:
      json.dump(data,fi,indent = 4)
    self.price = price
    self.stock = stock
    print(f"product {name} is updated successfully with {stock} in stock and {price} in price")

  def to_dict(self):
    return{
        "id":self.id,
        "name":self.name,
        "price":self.price,
        "stock":self.stock
    }

  @classmethod
  def from_dict(cls,data):
    return cls(
        id = data["id"],
        name = data["name"],
        price = data["price"],
        stock = data["stock"]
    )

