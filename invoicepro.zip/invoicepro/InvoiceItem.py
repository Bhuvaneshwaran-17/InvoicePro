class InvoiceItem:
  def __init__(self,product,quantity,total_price):
    self.product = product
    self.quantity = quantity
    self.total_price = total_price

